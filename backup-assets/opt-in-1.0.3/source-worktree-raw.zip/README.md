# 哔哩哔哩视频提取

独立的新项目，不读取或写入旧抖音程序的数据。

开发测试：先双击 `Setup-Dev.cmd` 安装 Python 依赖与 Chromium，再双击 `启动哔哩哔哩视频提取.vbs`。该启动文件不会显示命令框；`Start-Dev.cmd` 也会后台启动，不会保留命令框。

发布包：用户应从解压后的根目录双击 `Start-App.cmd`。有新版时会先询问是否下载；同意后只下载并校验更新包，本次仍启动当前版本。关闭程序后，下次启动才应用已暂存的更新。断网、拒绝下载或校验/替换失败时，启动器继续运行旧版。不要直接运行 `app` 内的 EXE，否则不会检查更新。

构建发布包：在隔离构建目录创建 `.venv` 并安装 `requirements.txt`、`pyinstaller` 后，运行 `powershell.exe -ExecutionPolicy Bypass -File .\build.ps1`。更新器测试也必须使用 Windows PowerShell 5.1（`powershell.exe`）；可用 `BILIBILI_PLAYWRIGHT_BROWSERS_PATH` 和 `BILIBILI_FFMPEG_EXE` 覆盖 Chromium 与 ffmpeg 的来源路径。构建不会读取或复制 `data`、`browser_session`、`logs`。

功能：批量 UP 主空间提取、关键词/话题提取、批量单视频提取，分钟级筛选、XLSX 另存为，以及当前账号可获取的最高画质下载。多 P 会下载为 `标题 - P01.mp4`、`标题 - P02.mp4` 等，并依赖完整发布包中的 ffmpeg 进行音视频合并。
